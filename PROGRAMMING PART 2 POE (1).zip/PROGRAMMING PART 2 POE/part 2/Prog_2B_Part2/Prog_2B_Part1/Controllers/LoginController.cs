﻿using Microsoft.AspNetCore.Mvc;

namespace Prog_2B_Part1.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string role)
        {
            if (role == "Lecturer")
                return RedirectToAction("SubmitClaim", "Lecturer");
            else if (role == "Manager")
                return RedirectToAction("ApproveClaims", "Manager");

            return View("Index");
        }
    }
}
