﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Prog_2B_Part1.Controllers
{
    public class ManagerController : Controller
    {
        public IActionResult ApproveClaims()
        {
            // Hardcoded Lecturer ID for demonstration
            var lecturerId = "L12345";
            ViewBag.LecturerId = lecturerId;

            // This action can be used to load claims data from a repository or service.
            return View();
        }

        [HttpPost]
        public IActionResult Approve(string action, string comments)
        {
            var lecturerId = "L12345"; // Hardcoded Lecturer ID for demonstration
            ViewBag.Message = action == "Approve" ? "Claim Approved!" : "Claim Rejected!";
            ViewBag.Comments = comments;
            ViewBag.LecturerId = lecturerId;

            return View("ApproveClaims");
        }
    }
}
