﻿using Microsoft.AspNetCore.Mvc;

namespace Prog_2B_Part1.Controllers
{
    public class LecturerController : Controller
    {
        public IActionResult SubmitClaim()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SubmitClaim(string lecturerId, string hoursWorked, IFormFile supportingDocuments)
        {
            // Placeholder for future functionality
            if (supportingDocuments != null && supportingDocuments.Length > 0)
            {
                // Save the file (this is a placeholder; actual implementation needed)
                // For example, save to a specific directory or cloud storage
                // var filePath = Path.Combine("uploads", supportingDocuments.FileName);
                // using (var stream = new FileStream(filePath, FileMode.Create))
                // {
                //     supportingDocuments.CopyTo(stream);
                // }
            }

            ViewBag.Message = $"Claim for {hoursWorked} hours submitted by Lecturer ID: {lecturerId}!";
            return View();
        }
    }
}
